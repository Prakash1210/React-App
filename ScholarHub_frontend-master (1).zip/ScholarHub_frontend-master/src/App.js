
import './App.css';
import Router from './component/Router';

function App() {
  return (
    <div className="App">
     <Router/>
    </div>
  );
}

export default App;
